#ifndef _DELAY_H_
#define _DELAY_H_

void delay( unsigned int t);

#endif