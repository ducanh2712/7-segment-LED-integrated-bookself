#ifndef _DHT11_H
#define  _DHT11_H_

void delay20ms();	
void delay30us();
void Request();		
void Response();		
int Receive_data();	

#endif